//
//  ViewController.swift
//  dz2Alert
//
//  Created by Gravman on 7/15/19.
//  Copyright © 2019 Alexandr_P. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func presentController(style: UIAlertController.Style){
        let alertController = UIAlertController(title: "Alarm", message: "Ваша система под угрозой", preferredStyle: style)
        let alert = UIAlertAction(title: "Close", style: .destructive) { (_) in
        }
        alertController.addAction(alert)
        present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func actionButton1(_ sender: Any) {
//        presentController(style: .alert)
        let alertController = UIAlertController(title: "Alarm", message: "Ваша система под угрозой, введите код доступа", preferredStyle: .alert)
        let alert = UIAlertAction(title: "Close", style: .destructive) { (_) in
        }
        let alert1 = UIAlertAction(title: "Ok", style: .default) { (_) in
        }
        alertController.addTextField { (_) in
        }
        alertController.addAction(alert1)
        alertController.addAction(alert)
        present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func actionButton2(_ sender: Any) {
        let alertController = UIAlertController (title: "Alarm", message: "Ваша система под угрозой", preferredStyle: .alert)
        let alert1 = UIAlertAction(title: "Show", style: .default) { (_) in
            self.presentController(style: .alert)
        }
        let alert2 = UIAlertAction(title: "Close", style: .destructive) { (_) in
        }
        alertController.addAction(alert1)
        alertController.addAction(alert2)
        present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func actionButton3 (_ sender: Any) {
    presentController(style: .actionSheet)
    }
}

