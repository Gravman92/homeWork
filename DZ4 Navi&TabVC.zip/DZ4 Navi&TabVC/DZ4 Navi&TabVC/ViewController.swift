//
//  ViewController.swift
//  DZ4 Navi&TabVC
//
//  Created by Gravman on 8/24/19.
//  Copyright © 2019 Alexandr_P. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func alertButt(_ sender: Any) {
        let alertContr = UIAlertController(title: "Warning", message: "Your device will be destroyed", preferredStyle: .alert)
        let alert = UIAlertAction(title: "Ok", style: .destructive) { _ in
            
        }
        alertContr.addAction(alert)
        present(alertContr, animated: true, completion: nil)
    }
    

}

