//
//  Global.swift
//  DZ4 Navi&TabVC
//
//  Created by Gravman on 8/25/19.
//  Copyright © 2019 Alexandr_P. All rights reserved.
//

import UIKit

//let alertControl = UIAlertController(title: "Hello", message: "", preferredStyle: .alert)
//let alert = UIAlertAction(title: "Ok", style: .default) { _ in}
