//
//  NaviVC1.swift
//  DZ4 Navi&TabVC
//
//  Created by Gravman on 8/25/19.
//  Copyright © 2019 Alexandr_P. All rights reserved.
//

import UIKit

class NaviVC1: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func firstBut(_ sender: Any) {
        let alertControl = UIAlertController(title: "Hello", message: "This is first NaviVC", preferredStyle: .alert)
        let alert = UIAlertAction(title: "Ok", style: .default) { _ in}
        alertControl.addAction(alert)
        present(alertControl, animated: true, completion: nil)
        
    }
    
}
