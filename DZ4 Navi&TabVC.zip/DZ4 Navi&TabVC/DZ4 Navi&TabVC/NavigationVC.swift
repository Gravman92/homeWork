//
//  NavigationVC.swift
//  DZ4 Navi&TabVC
//
//  Created by Gravman on 8/25/19.
//  Copyright © 2019 Alexandr_P. All rights reserved.
//

import UIKit

class NavigationVC: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
