//
//  SignUpVC.swift
//  DZ3_MVC
//
//  Created by Gravman on 8/24/19.
//  Copyright © 2019 Alexandr_P. All rights reserved.
//

import UIKit

class SignUpVC: UIViewController {
    @IBOutlet weak var loginField: UITextField!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var phoneField: UITextField!
    @IBOutlet weak var passField: UITextField!
    @IBOutlet weak var rePassField: UITextField!
    let alertContr = UIAlertController(title: "", message: "", preferredStyle: .alert)
    let alert = UIAlertAction(title: "Ok", style: .default) { _ in  }
    override func viewDidLoad() {
        super.viewDidLoad()


    }
    @IBAction func registerBut(_ sender: Any) {
        if loginField.text == login || emailField.text == email || phoneField.text == phone || passField.text != rePassField.text {
            alertContr.title = "Error"
            alertContr.message = "Enter other param"
            alertContr.addAction(alert)
            present(alertContr, animated: true, completion: nil)
        } else {
            alertContr.title = "Congratulation"
            alertContr.message = "You are register"
            alertContr.addAction(alert)
            present(alertContr, animated: true, completion: nil)
        }
    }
}
