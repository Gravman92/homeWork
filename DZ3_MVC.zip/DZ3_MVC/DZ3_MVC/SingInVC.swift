//
//  SingInVC.swift
//  DZ3_MVC
//
//  Created by Gravman on 8/24/19.
//  Copyright © 2019 Alexandr_P. All rights reserved.
//

import UIKit

class SingInVC: UIViewController {

    @IBOutlet weak var loginTextField: UITextField!
    @IBOutlet weak var passTextField: UITextField!
    let alertContr = UIAlertController(title: "", message: "", preferredStyle: .alert)
    let alert = UIAlertAction(title: "Ok", style: .default) { _ in  }
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func confirmButt(_ sender: Any) {
        if loginTextField.text != login || passTextField.text != password {
            alertContr.title = "Error"
            alertContr.message = "Enter correct login or password"
            alertContr.addAction(alert)
            present(alertContr, animated: true, completion: nil)
        } else {
            alertContr.title = "Congratulation"
            alertContr.message = "You are login"
            alertContr.addAction(alert)
            present(alertContr, animated: true, completion: nil)
        }
    }
}
    

