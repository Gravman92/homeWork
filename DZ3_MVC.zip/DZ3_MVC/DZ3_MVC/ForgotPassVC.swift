//
//  ForgotPassVC.swift
//  DZ3_MVC
//
//  Created by Gravman on 8/24/19.
//  Copyright © 2019 Alexandr_P. All rights reserved.
//

import UIKit

class ForgotPassVC: UIViewController {
    
    @IBOutlet weak var newPassField: UITextField!
    var newPass: String = ""
    let alertContr = UIAlertController(title: "", message: "", preferredStyle: .alert)
    let alert = UIAlertAction(title: "Ok", style: .default) { _ in  }
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

    @IBAction func confirmBut(_ sender: Any) {
        if newPassField.text == password {
            alertContr.title = "Error"
            alertContr.message = "Your new password is equal old"
            alertContr.addAction(alert)
            present(alertContr, animated: true, completion: nil)
        } else {
            guard let newPass = newPassField.text else { return }
            password = newPass
            alertContr.title = "Congratulation"
            alertContr.message = "You password \(newPass)"
            alertContr.addAction(alert)
            present(alertContr, animated: true, completion: nil)
        }
    }
}
