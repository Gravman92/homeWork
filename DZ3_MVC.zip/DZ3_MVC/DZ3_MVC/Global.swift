//
//  Global.swift
//  DZ3_MVC
//
//  Created by Gravman on 8/24/19.
//  Copyright © 2019 Alexandr_P. All rights reserved.
//

import UIKit
import Foundation

var login: String = "User"
var password: String = "Password"
var email: String = "email@icloud.com"
var phone: String = "+380973943738"

